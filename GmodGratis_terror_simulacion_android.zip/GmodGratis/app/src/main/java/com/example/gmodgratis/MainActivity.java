package com.example.gmodgratis;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.Random;

public class MainActivity extends Activity {
 TextView title,msg; LinearLayout buttons; Handler h=new Handler(); Random r=new Random();
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);title=findViewById(R.id.title);msg=findViewById(R.id.message);buttons=findViewById(R.id.buttons); if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){new AlertDialog.Builder(this).setTitle("Permiso opcional").setMessage("Permite mostrar una ventana flotante para efectos visuales. La aplicación no controla otras apps ni toca tus archivos.").setPositiveButton("Permitir",(d,w)->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())))).setNegativeButton("Ahora no",null).show();} sequence();}
 void sequence(){title.setText("GMOD GRATIS");msg.setText("");h.postDelayed(()->msg.setText("CREISTE QUE ERA REAL"),1200);h.postDelayed(()->{title.setText("YOU ARE IDIOT");msg.setText("JA JA JA");},3000);h.postDelayed(()->{title.setText("ADVERTENCIA");msg.setText("Tus archivos han sido encriptados.\n\nSi los quieres, haz lo que te diga.");},5000);h.postDelayed(()->{msg.setText("PULSA ENTER");button("PULSA ENTER",v->game());},7300);}
 void clear(){buttons.removeAllViews();}
 void button(String s,View.OnClickListener l){clear();Button b=new Button(this);b.setText(s);b.setOnClickListener(l);buttons.addView(b);}
 void game(){title.setText("PIEDRA PAPEL TIJERA");msg.setText("Elige tu jugada");clear();String[] n={"PIEDRA","PAPEL","TIJERA"};for(int i=0;i<3;i++){final int c=i;buttonAdd(n[i],v->round(c));}}
 void buttonAdd(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);buttons.addView(b);}
 void round(int p){int c=r.nextInt(3);String[] n={"PIEDRA","PAPEL","TIJERA"};msg.setText("TU JUGADA: "+n[p]+"\nJUGADA DEL SISTEMA: "+n[c]);if(p==c){h.postDelayed(this::game,1000);return;}boolean win=(p==0&&c==2)||(p==1&&c==0)||(p==2&&c==1);h.postDelayed(()->{if(win){title.setText("HAS GANADO");msg.setText("La aplicación se cerrará.");clear();}else{title.setText("PERDISTE");msg.setText("Su dispositivo ha sido salvado.");clear();}h.postDelayed(this::finish,1800);},900);}
}
